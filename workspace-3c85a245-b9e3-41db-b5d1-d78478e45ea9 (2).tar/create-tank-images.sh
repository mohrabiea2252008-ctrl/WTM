#!/bin/bash

# Create tank images directory structure
mkdir -p /home/z/my-project/public/tanks

# Function to create SVG tank image
create_tank_svg() {
    local name="$1"
    local type="$2"
    local nation="$3"
    local color="$4"
    local filename="$5"
    
    cat > "/home/z/my-project/public/tanks/$filename" << SVGEOF
<svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <rect width="200" height="200" fill="$color"/>
  <text x="100" y="100" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-size="12" font-weight="bold">$name</text>
  <text x="100" y="120" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-size="10">$type</text>
  <text x="100" y="140" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-size="8">$nation</text>
</svg>
EOF
}

# Create some sample tank images
create_tank_svg "M4A1 (76) W" "Medium Tank" "USA" "#4B5563" "m4a1-76-w.svg"
create_tank_svg "Pz.IV F2" "Medium Tank" "Germany" "#6B7280" "pziv-f2.png"
create_tank_svg "T-34 (1940)" "Heavy Tank" "USSR" "#DC2626" "t34-1940.png"
create_tank_svg "KV-2" "Heavy Tank" "USSR" "#DC2626" "kv2-premium.png"
create_tank_svg "Tiger H1" "Heavy Tank" "Germany" "#6B7280" "tiger-h1.png"
create_tank_svg "Leopard I" "Medium Tank" "Germany" "#6B7280" "leopard-i.png"
create_tank_svg "M1 Abrams" "Medium Tank" "USA" "#4B5563" "m1-abrams.png"
create_tank_svg "Challenger 2" "Heavy Tank" "UK" "#059669" "challenger-2-tes.png"

echo "Tank images created successfully!"