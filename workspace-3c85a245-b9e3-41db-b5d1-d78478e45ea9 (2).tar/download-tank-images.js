import https from 'https'
import fs from 'fs'
import path from 'path'

// Function to download image from URL
async function downloadImage(url, filename) {
  try {
    const response = await fetch(url)
    const buffer = await response.arrayBuffer()
    fs.writeFileSync(filename, buffer)
    console.log(`Downloaded: ${filename} from ${url}`)
    return filename
  } catch (error) {
    console.error(`Failed to download ${url}: ${error.message}`)
    return null
  }
}

// Download some tank images
async function downloadTankImages() {
  const tanks = [
    {
      name: 'm4a1-76-w',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/M4_Sherman_76mm_Gun_tank_76mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/M4_Sherman_76mm_Gun_tank_76mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/M4_Sherman_76mm_Gun_tank_76mm_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'pziv-f2',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/PzIV_F2_75mm_Gun_tank_75mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/PzIV_F2_75mm_Gun_tank_75mm_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'tiger-h1',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Tiger_I_88mm_Gun_tank_88mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Tiger_I_88mm_Gun_tank_88mm_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'kv2-premium',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/KV-2_152mm_howitzer_152mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/KV-2_152mm_howitzer_152mm_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'leopard-i',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Leopard_1_105mm_L/44_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Leopard_1_105mm_L/44_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'm1-abrams',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/M1_Abrams_105mm_Gun_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/M1_Abrams_105mm_Gun_in_Northern_Europe.jpg'
      ]
    },
    {
      name: 'challenger-2-tes',
      urls: [
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Challenger_2_(FV4202_Challenger_2_FV4202_Challenger_2)_in_Northern_Europe.jpg',
        'https://upload.wikimedia.org/wikipedia/commons/1/1f/Challenger_2_(FV4202_Challenger_2)_in_Northern_Europe.jpg'
      ]
    }
  ]
  
  console.log('Starting tank image downloads...')
  
  for (const tank of tanks) {
    console.log(`Downloading images for ${tank.name}...`)
    
    for (const url of tank.urls) {
      const filename = `/home/z/my-project/public/tanks/${tank.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, '_')}.png`
      await downloadImage(url, filename)
    }
    
    console.log('All downloads completed!')
  }
}

downloadTankImages()