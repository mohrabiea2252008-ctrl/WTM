import React from 'react'
import { TankIcon } from './TankIcon'

interface TankPlaceholderProps {
  name: string
  type: string
  nation: string
  className?: string
}

export function TankPlaceholder({ name, type, nation, className = "" }: TankPlaceholderProps) {
  const getNationColor = (nation: string) => {
    switch (nation) {
      case 'USA': return 'bg-blue-600'
      case 'Germany': return 'bg-gray-600'
      case 'USSR': return 'bg-red-600'
      case 'UK': return 'bg-green-600'
      case 'France': return 'bg-purple-600'
      case 'Japan': return 'bg-pink-600'
      case 'China': return 'bg-yellow-600'
      case 'Italy': return 'bg-orange-600'
      case 'Sweden': return 'bg-cyan-600'
      case 'Israel': return 'bg-indigo-600'
      case 'Hungary': return 'bg-teal-600'
      case 'South Africa': return 'bg-lime-600'
      default: return 'bg-gray-500'
    }
  }

  return (
    <div className={`relative w-full h-full ${getNationColor(nation)} ${className} flex items-center justify-center`}>
      <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      <div className="relative text-center text-white p-4">
        <div className="w-16 h-16 mx-auto mb-2 text-white opacity-80">
          <TankIcon type={type} className="w-full h-full" />
        </div>
        <div className="text-xs font-bold mb-1 truncate">{name}</div>
        <div className="text-xs opacity-75">{type}</div>
        <div className="text-xs opacity-50">{nation}</div>
      </div>
    </div>
  )
}