import React from 'react'

interface TankIconProps {
  type: string
  className?: string
}

export function TankIcon({ type, className = "" }: TankIconProps) {
  const getTankSVG = (type: string) => {
    switch (type) {
      case 'Heavy Tank':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="20" y="30" width="60" height="40" fill="currentColor" />
            <rect x="30" y="20" width="40" height="30" fill="currentColor" />
            <circle cx="50" cy="35" r="8" fill="currentColor" />
            <rect x="45" y="60" width="10" height="20" fill="currentColor" />
          </svg>
        )
      case 'Medium Tank':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="25" y="35" width="50" height="30" fill="currentColor" />
            <rect x="35" y="25" width="30" height="25" fill="currentColor" />
            <circle cx="50" cy="40" r="6" fill="currentColor" />
            <rect x="47" y="60" width="6" height="15" fill="currentColor" />
          </svg>
        )
      case 'Light Tank':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="30" y="40" width="40" height="20" fill="currentColor" />
            <rect x="40" y="35" width="20" height="20" fill="currentColor" />
            <circle cx="50" cy="45" r="4" fill="currentColor" />
            <rect x="48" y="55" width="4" height="10" fill="currentColor" />
          </svg>
        )
      case 'Tank Destroyer':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="15" y="30" width="70" height="35" fill="currentColor" />
            <circle cx="50" cy="35" r="8" fill="currentColor" />
            <rect x="47" y="60" width="6" height="20" fill="currentColor" />
          </svg>
        )
      case 'Self-propelled Gun':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="20" y="40" width="60" height="25" fill="currentColor" />
            <rect x="25" y="25" width="50" height="20" fill="currentColor" />
            <rect x="35" y="10" width="30" height="15" fill="currentColor" />
            <rect x="47" y="60" width="6" height="15" fill="currentColor" />
          </svg>
        )
      case 'Assault Gun':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="15" y="35" width="70" height="30" fill="currentColor" />
            <rect x="25" y="25" width="50" height="25" fill="currentColor" />
            <circle cx="50" cy="35" r="8" fill="currentColor" />
            <rect x="47" y="60" width="6" height="20" fill="currentColor" />
          </svg>
        )
      case 'Support Vehicle':
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="25" y="35" width="50" height="30" fill="currentColor" />
            <rect x="35" y="25" width="30" height="25" fill="currentColor" />
            <rect x="40" y="50" width="20" height="10" fill="currentColor" />
            <rect x="47" y="60" width="6" height="15" fill="currentColor" />
          </svg>
        )
      default:
        return (
          <svg viewBox="0 0 100 100" className={className}>
            <rect x="25" y="35" width="50" height="30" fill="currentColor" />
            <rect x="35" y="25" width="30" height="25" fill="currentColor" />
            <circle cx="50" cy="40" r="6" fill="currentColor" />
            <rect x="47" y="60" width="6" height="15" fill="currentColor" />
          </svg>
        )
    }
  }

  return (
    <div className="w-full h-full flex items-center justify-center">
      {getTankSVG(type)}
    </div>
  )
}