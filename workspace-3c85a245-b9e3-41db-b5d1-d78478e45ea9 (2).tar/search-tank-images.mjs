import ZAI from 'z-ai-web-dev-sdk'

export async function searchTankImages() {
  try {
    const zai = await ZAI.create()
    
    // Search for M4A1 Sherman images
    const searchResult = await zai.functions.invoke("web_search", {
      query: "M4A1 Sherman tank images Wikipedia",
      num: 5
    })
    
    console.log('Search results for M4A1 Sherman:')
    searchResult.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`   URL: ${result.url}`)
      console.log(`   Snippet: ${result.snippet}`)
      console.log(`   Host: ${result.host_name}`)
      console.log('---')
    })
    
    // Search for Tiger tank images
    const tigerSearch = await zai.functions.invoke("web_search", {
      query: "Tiger tank images War Thunder",
      num: 5
    })
    
    console.log('\nSearch results for Tiger tank:')
    tigerSearch.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`   URL: ${result.url}`)
      console.log(`   Snippet: ${result.snippet}`)
      console.log(`   Host: ${result.host_name}`)
      console.log('---')
    })
    
    // Search for general tank images
    const tankSearch = await zai.functions.invoke("web_search", {
      query: "tank images database War Thunder Mobile",
      num: 5
    })
    
    console.log('\nSearch results for tank database:')
    tankSearch.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`   URL: ${result.url}`)
      console.log(`   Snippet: ${result.snippet}`)
      console.log(`   Host: ${result.host_name}`)
      console.log('---')
    })
    
    return { searchResult, tigerSearch, tankSearch }
  } catch (error) {
    console.error('Error searching for tank images:', error.message)
    return null
  }
}

export { searchTankImages }