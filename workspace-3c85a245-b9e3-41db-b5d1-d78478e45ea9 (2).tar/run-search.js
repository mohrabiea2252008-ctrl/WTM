const ZAI = require('z-ai-web-dev-sdk')

async function runSearch() {
  try {
    console.log('Searching for tank images...')
    
    // Search for M4A1 Sherman
    const m4a1Result = await ZAI.functions.invoke("web_search", {
      query: "M4A1 Sherman tank Wikipedia images",
      num: 3
    })
    
    console.log('\n=== M4A1 Sherman Results ===')
    m4a1Result.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`URL: ${result.url}`)
      console.log(`Host: ${result.host_name}`)
      console.log(`Snippet: ${result.snippet}`)
      console.log('---')
    })
    
    // Search for Tiger tank
    const tigerResult = ZAI.functions.invoke("web_search", {
      query: "Tiger tank War Thunder images",
      num: 3
    })
    
    console.log('\n=== Tiger Tank Results ===')
    tigerResult.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`URL: ${result.url}: ${result.url}`)
      console.log(`Host: ${result.host_name}`)
      console.log(`Snippet: ${result.snippet}`)
      console.log('---')
    })
    
    // Search for general tank images
    const tankResult = ZAI.functions.invoke("web_search", {
      query: "War Thunder tank database images",
      num: 3
    })
    
    console.log('\n=== General Tank Results ===')
    tankResult.forEach((result, index) => {
      console.log(`${index + 1}. ${result.name}`)
      console.log(`URL: ${result.url}: ${result.url}`)
      console.log(`Host: ${result.host_name}`)
      console.log(`Snippet: ${result.snippet}`)
      console.log('---')
    })
    
    return { m4a1Result, tigerResult, tankResult }
  } catch (error) {
    console.error('Search failed:', error.message)
  }
}

runSearch()